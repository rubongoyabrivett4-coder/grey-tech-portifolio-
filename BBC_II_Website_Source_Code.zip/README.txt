BBC II WEBSITE SOURCE CODE
===========================

Files:
- index.html   Home page
- about.html   About Us page
- contact.html Contact Us page
- style.css    Shared styling

Open index.html in a browser to run the website.

The three navigation buttons connect the pages.
The contact form currently shows a confirmation message in the browser; it does not send email to a server.

The resort images use public Unsplash image URLs, so internet access is needed for those images to appear.
