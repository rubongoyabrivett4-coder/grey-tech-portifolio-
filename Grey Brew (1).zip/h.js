
function toggleMenu() {
    const nav = document.getElementById("nav");

    nav.classList.toggle("active");
}

// Close menu after clicking a navigation link

const links = document.querySelectorAll("#nav a");

links.forEach(function(link) {
    link.addEventListener("click", function() {
        document.getElementById("nav").classList.remove("active");
    });
});
