HEALTHY RECIPE FINDER WEBSITE

Files:
- index.html: the website structure and text
- style.css: colors, spacing, card layout, and mobile responsive design
- images/: your uploaded pictures and crops from the supplied screenshot

How to use:
1. Extract healthy-recipe-finder.zip.
2. Keep index.html, style.css, and the images folder together.
3. Open index.html in a browser.
4. To edit the website, open index.html and style.css in VS Code.

To change a picture, replace the matching image in the images folder and keep the filename the same.
The form is currently a front-end demo; it does not send enquiries to a server.
