MAE Restaurant website
======================

Files:
- index.html: website structure
- style.css: responsive design
- script.js: mobile navigation and demo booking form
- assets/logo.jpg: your supplied MAE logo
- assets/chef.jpg: your supplied chef photo

Preview:
Open index.html in a browser. Internet access is needed for the Google Fonts and placeholder food/gallery photos.

Before publishing:
1. Replace sample menu items/prices with your real menu.
2. Update the restaurant's address, phone number, opening hours and social links.
3. Connect the reservation form to WhatsApp, email, or a booking backend. It currently shows a demo confirmation only.
4. Replace the online placeholder photos with your own photos if desired.

You can publish the folder using GitHub Pages, Netlify, or another static website host.
